# -*- coding: utf-8 -*-
{
    'name': "SIANTOU - EMS Core App",
    'category': 'Education',
    'version': '17.0.0.0',
    'depends': ['base', 'web', 'sale', 'board', 'hr','account','mail'],
    'data': [
        # Fichiers de datas
        # 'data/email_template_preinscription.xml',
        # 'data/email_template_preinscription_conditionnelle.xml',
        # 'data/sequence_preinscription.xml',
        
        # Fichiers de sécurité
        'security/module_category_school_management.xml',
        'security/group_school_management.xml',
        'security/ir.model.access.csv',

        # Fichier des groups
        'views/res_groups_action.xml',
        'views/res_groups_menu.xml',

        # Fichier des menus
        'views/menu_views.xml',

        # Fichier de la section admin
        # 'views/admin_views.xml',

        # Fichier des vues
        'views/year_views.xml',
        'views/semester_views.xml',
        'views/fieldofstudy_views.xml',
        'views/subject_views.xml',
        'views/teacher_views.xml',
        'views/building_views.xml',
        'views/campus_views.xml',
        'views/classroom_views.xml',
        'views/level_views.xml',
        'views/university_views.xml',
        'views/students_career_views.xml',
        'views/batch_views.xml',
        'views/school_views.xml',
        'views/admission_registre_view.xml',
        'views/admission_session_view.xml',

        'views/student_enrollment_views.xml',
        'views/students_views.xml',
        'views/course_views.xml',
        'views/degree_course_views.xml',
        # 'views/fee_struct_views.xml',
        # 'views/fee_struct_line_views.xml',


        # 'views/fee_enrollment_views.xml',
        'views/country_views.xml',
        'views/region_views.xml',
        'views/city_views.xml',
        'views/quarter_views.xml',

        'views/country_views.xml',


        'wizard/fee_student_wizard.xml',
        'wizard/student_enroll_admission_wizard.xml',


        # Fichier de vue timetable
        'views/timetable_views.xml',
        'views/timetable_group_views.xml',
        'views/timetable_wizard_views.xml',
        'views/timetable_print_wizard_views.xml',
        'report/timetable_reports.xml',
        'report/timetable_template.xml',
        'report/report_student_core.xml',

        #=========== Fichier du dashboard
        'views/ems_core_dashboard.xml',
    ],
    'license': 'LGPL-3',
    'installable': True,
    'application': True,
    'auto_install': False,
    'assets': {
        'web.assets_backend': [
            'siantou_ems_core/static/src/components/**/*.js',
            'siantou_ems_core/static/src/components/**/*.xml',
            'siantou_ems_core/static/src/components/**/*.scss',
        ],
    },
}
